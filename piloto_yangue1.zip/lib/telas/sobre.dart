import 'package:flutter/material.dart';
// ignore: unused_import
import 'package:piloto_yangue1/componentes/decoration.dart';
class Sobre extends StatelessWidget {
  const Sobre({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body:Center(child:const Text("Nossas Informação")),
    );
  }
}
