import 'package:flutter/material.dart';
import 'package:piloto_yangue1/componentes/decoration.dart';
import 'package:piloto_yangue1/telas/home_piloto.dart';

class ServicosCargas extends StatelessWidget {
  const ServicosCargas({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: const Center (
          child:  Text(""),
        ),
       
        );
  }
}