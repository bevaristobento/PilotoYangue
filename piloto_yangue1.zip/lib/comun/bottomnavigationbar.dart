import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:piloto_yangue1/componentes/decoration.dart';
import 'package:piloto_yangue1/telas/auth_piloto.dart';
import 'package:piloto_yangue1/telas/contas.dart';
import 'package:piloto_yangue1/telas/home_piloto.dart';
import 'package:piloto_yangue1/telas/servi%C3%A7o_carga.dart';
import 'package:piloto_yangue1/telas/sobre.dart';

// ignore: must_be_immutable
class Navigation extends StatelessWidget {
  Navigation({super.key});
  
 int currentIndex = 0;
  static const screen = [
    AuthenticionPiloto(),
    ServicosCargas(),
    Contas(),
    Sobre(),
  ];
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      
      
      body: screen[currentIndex],
       
    );
  }
  
}