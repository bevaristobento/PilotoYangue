// ignore: unused_import
import 'package:flutter/material.dart';

class CoresPiloto
{
  static const Color amarelosuperior = Color.fromARGB(255, 255, 255, 255);

  static const Color amareloinferior = Color.fromARGB(230, 255, 255, 255);

}